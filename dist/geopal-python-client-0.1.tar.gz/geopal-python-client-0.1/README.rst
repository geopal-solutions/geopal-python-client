Simple GeoPal Python Client.

Simple GeoPal python client allows to test GeoPal api. Script allows you to:
1) Create a job
2) Read a job
3) List of job templates
4) Read job template
5) Read jobs between date range
6) Employees list
7) Employees list in XML

To be able to use this script in live mode you need valid api key and user name. 
To obtain this information please contact us at support@geopal-solutions.com.

Regards
GeoPal Team.